package com.terkul.liveoverlay

import android.service.notification.NotificationListenerService

// ว่างเปล่าโดยตั้งใจ: ใช้แค่ให้ระบบอนุญาตให้แอปอ่าน MediaSession (คุม Spotify)
class MediaListener : NotificationListenerService()
