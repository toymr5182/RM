package com.terkul.liveoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }

        col.addView(TextView(this).apply {
            text = "Live Overlay\nTikTok Live + Spotify ลอยทับเกม"
            textSize = 20f
        })

        val input = EditText(this).apply {
            hint = "@username หรือลิงก์ TikTok Live"
            setSingleLine(true)
            setText(prefs.getString("url", ""))
        }
        col.addView(input)

        val desk = CheckBox(this).apply {
            text = "โหมดเดสก์ท็อป (ถ้าสตรีมไม่ขึ้น ให้ลองปิดตัวนี้)"
            isChecked = prefs.getBoolean("desktop", true)
        }
        col.addView(desk)

        fun addBtn(label: String, action: () -> Unit) {
            col.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        addBtn("1) อนุญาตแสดงทับแอปอื่น") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addBtn("2) อนุญาตเข้าถึงการแจ้งเตือน (ไว้คุม Spotify)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addBtn("เริ่ม") {
            val raw = input.text.toString().trim()
            if (raw.isEmpty()) {
                Toast.makeText(this, "ใส่ @username หรือลิงก์ก่อน", Toast.LENGTH_SHORT).show()
            } else if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "ต้องกดข้อ 1 ก่อน", Toast.LENGTH_SHORT).show()
            } else {
                val url = if (raw.startsWith("http")) raw
                else "https://www.tiktok.com/@" + raw.removePrefix("@") + "/live"
                prefs.edit().putString("url", raw).putBoolean("desktop", desk.isChecked).apply()
                prefs.edit().putString("fullUrl", url).apply()
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        addBtn("หยุด") {
            stopService(Intent(this, OverlayService::class.java))
        }

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
