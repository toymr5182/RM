package com.terkul.liveoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var videoRoot: LinearLayout? = null
    private var musicRoot: LinearLayout? = null
    private var webView: WebView? = null

    private lateinit var titleView: TextView
    private lateinit var playBtn: TextView
    private var controller: MediaController? = null
    private var msm: MediaSessionManager? = null

    private val DESKTOP_UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { refreshMusic() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { refreshMusic() }
    }

    private val sessionListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, buildNotification())
        }
        if (videoRoot == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
            val url = prefs.getString("fullUrl", "https://www.tiktok.com") ?: "https://www.tiktok.com"
            val desktop = prefs.getBoolean("desktop", true)
            buildMusic()
            buildVideo(url, desktop)
            connectMedia()
        }
        return START_NOT_STICKY
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(10).toFloat()
    }

    private fun overlayParams(px: Int, py: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = px
        y = py
    }

    private fun btn(label: String, onClick: (TextView) -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 11f
        t.setPadding(dp(6), dp(8), dp(6), dp(8))
        t.setOnClickListener { onClick(t) }
        return t
    }

    private fun makeDraggable(handle: View, params: WindowManager.LayoutParams, root: View) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = sx + (e.rawX - tx).toInt()
                    params.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }
    }

    // ---------- video window ----------

    private fun buildVideo(url: String, desktop: Boolean) {
        val params = overlayParams(dp(8), dp(64))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#E6101018"))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#FF1E1E2A"))
        }
        val handle = TextView(this).apply {
            text = "≡"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(10), dp(4), dp(10), dp(4))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        header.addView(handle)

        val wv = WebView(this)
        webView = wv
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            if (desktop) userAgentString = DESKTOP_UA
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val s = request.url.scheme ?: return true
                return s != "http" && s != "https" // กันเด้งไปเปิดแอป TikTok
            }
        }
        wv.loadUrl(url)

        val sizes = if (desktop) listOf(320 to 200, 420 to 260, 520 to 320)
        else listOf(200 to 356, 250 to 444, 300 to 533)
        var sizeIdx = 1
        fun applySize() {
            wv.layoutParams = LinearLayout.LayoutParams(dp(sizes[sizeIdx].first), dp(sizes[sizeIdx].second))
            root.requestLayout()
            wm.updateViewLayout(root, params)
        }

        var typing = false
        header.addView(btn("พิมพ์") { b ->
            typing = !typing
            params.flags = if (typing)
                params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            else
                params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            wm.updateViewLayout(root, params)
            b.text = if (typing) "เล่นเกม" else "พิมพ์"
        })
        header.addView(btn("ขนาด") {
            sizeIdx = (sizeIdx + 1) % sizes.size
            applySize()
        })
        val alphas = floatArrayOf(1f, 0.7f, 0.45f)
        var aIdx = 0
        header.addView(btn("จาง") {
            aIdx = (aIdx + 1) % alphas.size
            root.alpha = alphas[aIdx]
        })
        var folded = false
        header.addView(btn("พับ") { b ->
            folded = !folded
            wv.visibility = if (folded) View.GONE else View.VISIBLE
            if (folded) wv.onPause() else wv.onResume()
            b.text = if (folded) "กาง" else "พับ"
        })
        header.addView(btn("✕") { stopSelf() })

        root.addView(header)
        root.addView(wv, LinearLayout.LayoutParams(dp(sizes[sizeIdx].first), dp(sizes[sizeIdx].second)))

        makeDraggable(handle, params, root)
        videoRoot = root
        wm.addView(root, params)
    }

    // ---------- music bar ----------

    private fun buildMusic() {
        val params = overlayParams(dp(8), dp(8))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.parseColor("#E6101018"))
            setPadding(dp(4), 0, dp(4), 0)
        }
        titleView = TextView(this).apply {
            text = "Spotify: ยังไม่มีเพลง"
            setTextColor(Color.WHITE)
            textSize = 11f
            maxWidth = dp(140)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        playBtn = btn("▶") {
            val c = controller
            if (c != null) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                else c.transportControls.play()
            }
        }
        root.addView(titleView)
        root.addView(btn("◀◀") { controller?.transportControls?.skipToPrevious() })
        root.addView(playBtn)
        root.addView(btn("▶▶") { controller?.transportControls?.skipToNext() })

        makeDraggable(titleView, params, root)
        musicRoot = root
        wm.addView(root, params)
    }

    private fun connectMedia() {
        val m = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm = m
        val cn = ComponentName(this, MediaListener::class.java)
        try {
            pick(m.getActiveSessions(cn))
            m.addOnActiveSessionsChangedListener(sessionListener, cn)
        } catch (e: SecurityException) {
            titleView.text = "เปิดสิทธิ์เข้าถึงการแจ้งเตือนก่อน"
        }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(mediaCb)
        controller = list?.firstOrNull { it.packageName == "com.spotify.music" } ?: list?.firstOrNull()
        controller?.registerCallback(mediaCb, Handler(Looper.getMainLooper()))
        refreshMusic()
    }

    private fun refreshMusic() {
        val c = controller
        if (c == null) {
            titleView.text = "ไม่พบเพลง (เปิด Spotify ก่อน)"
            playBtn.text = "▶"
            return
        }
        val m = c.metadata
        val t = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "-"
        val a = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        titleView.text = if (a.isEmpty()) t else "$t - $a"
        playBtn.text = if (c.playbackState?.state == PlaybackState.STATE_PLAYING) "||" else "▶"
    }

    // ---------- notification / lifecycle ----------

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ov", "Live Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Live Overlay ทำงานอยู่")
            .addAction(android.R.drawable.ic_delete, "ปิด", stop)
            .build()
    }

    override fun onDestroy() {
        try { controller?.unregisterCallback(mediaCb) } catch (_: Exception) {}
        try { msm?.removeOnActiveSessionsChangedListener(sessionListener) } catch (_: Exception) {}
        try { videoRoot?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { musicRoot?.let { wm.removeView(it) } } catch (_: Exception) {}
        webView?.destroy()
        videoRoot = null
        musicRoot = null
        super.onDestroy()
    }
}
