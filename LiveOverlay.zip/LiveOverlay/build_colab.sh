#!/bin/bash
# รันใน Colab:  !bash build_colab.sh   (ใช้เวลา ~5-8 นาที)
set -e
apt-get update -qq && apt-get install -y -qq openjdk-17-jdk unzip wget >/dev/null
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=/opt/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools
if [ ! -d $ANDROID_HOME/cmdline-tools/latest ]; then
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O /tmp/cmd.zip
  unzip -q /tmp/cmd.zip -d /tmp/cmd
  mv /tmp/cmd/cmdline-tools $ANDROID_HOME/cmdline-tools/latest
fi
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses >/dev/null
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools" >/dev/null
if [ ! -d /opt/gradle-8.9 ]; then
  wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip -O /tmp/g.zip
  unzip -q /tmp/g.zip -d /opt
fi
echo "sdk.dir=$ANDROID_HOME" > local.properties
/opt/gradle-8.9/bin/gradle assembleDebug --no-daemon
echo "เสร็จแล้ว: app/build/outputs/apk/debug/app-debug.apk"
